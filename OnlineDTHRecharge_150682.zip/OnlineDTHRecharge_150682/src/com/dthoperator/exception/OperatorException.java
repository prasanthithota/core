/*******Author Name: sri vani bobbili  Emp Id : 150682 Date: 7/5/2018 ******/
//Purpose: To define exceptions for invalid input
package com.dthoperator.exception;

public class OperatorException extends Exception{
	private static final long serialVersionUID = 1L;
	public OperatorException()
	{
		super();
	}
	public OperatorException(String message,Throwable cause, boolean enableSuppression, boolean WritableStackTrace)
	{
		super(message, cause, enableSuppression, WritableStackTrace);
	}
	public OperatorException(String message, Throwable cause)
	{
		super(message, cause);
	}

	public OperatorException(String message) 
	{
		super(message);			
	}
	public OperatorException(Throwable cause) 
	{
		super(cause);			
	}	
}
