package com.dthoperator.ui;
import java.util.Random;
import java.util.Scanner;

import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.exception.OperatorException;
import com.dthoperator.service.RechargeCollectionHelper;
import com.dthoperator.service.RechargeDataValidator;

public class RechargeClient {
	//creating as static so that they can available outside the main() also
	static Scanner sc = new Scanner(System.in);
	static RechargeCollectionHelper collectionhelper = null;
	// Main method
	public static void main(String[] args) throws OperatorException {
		// TODO Auto-generated method stub
		collectionhelper = new RechargeCollectionHelper();
		
		//writing infinite loop so that it can run till the user exit the application 
		while(true)
		{
			//Providing user interface
			System.out.println("1. Mark a Recharge");
			System.out.println("2. Display Recharge Details");
			System.out.println("3. Exit.");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch(choice)
			{ 
			case 1:
				System.out.println("Select DTH Operator(Airtel /DishTV /Reliance /TATASky)");
				String operator = sc.next();
				//sending input to validatedthOperator for validating operator
				if(RechargeDataValidator.validatedthOperator(operator))
				{
					try{
					System.out.println("Enter Registered Consumer No.: ");
					String consumerno =sc.next();
					//sending input to validateConsumerNo for validating consumerNo
					if(RechargeDataValidator.validateConsumerNo(consumerno,operator))
					{
						System.out.println("Select Plan (Monthly /Quarterly /Half Yearly/ Annual)");
						String plan =sc.next();
						//sending input to validatePlan for validating plan
						if(RechargeDataValidator.validatePlan(plan))
						{
							System.out.println("Enter Amount (Rs.): ");
							int amount = sc.nextInt();
							//sending input to validateAmount for validating amount
							if(RechargeDataValidator.validateAmount(amount))
							{
								//Generate  Random Reference Id
								Random ran=new Random();
								long TransId=ran.nextInt(1000);
								System.out.println("Successful Recharge. Transaction ID : <"+TransId + ">");
								//sending valid input data to the constructor of RechargeDetails class
								RechargeDetails opdetails = new RechargeDetails(operator,consumerno,plan,amount,TransId);
								collectionhelper.addDetails(opdetails);
								//displaying all the existing RechargeDetails of the list
								//collectionhelper.displayDetails();
							}
							
						}
						
					}
					
					}
					catch(Exception e)
					{
						System.out.println(e.getMessage());
					}
				}
				break;
			case 2: 
				//displaying all the existing RechargeDetails of the list
				collectionhelper.displayDetails();
				break;
			case 3:
				//exit of the entry
				System.out.println("Exiting...");
				System.exit(0);
			break;
			default:
				//message for invalid data
				System.out.println("Invalid choice");
				break;
				
			}
		}
	}
}
