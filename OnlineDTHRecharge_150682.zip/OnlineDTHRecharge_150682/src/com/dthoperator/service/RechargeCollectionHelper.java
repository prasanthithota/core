/*******Author Name: sri vani bobbili  Emp Id : 150682 Date: 7/5/2018 ******/
//Purpose: To create arraylist for adding & displaying RechargeDetails
package com.dthoperator.service;



import java.util.ArrayList;
import java.util.Iterator;

import com.dthoperator.bean.RechargeDetails;

public class RechargeCollectionHelper {

	private  static ArrayList<RechargeDetails> list=null;
	static
	{
		//creating array list and adding default data
		list=new ArrayList<RechargeDetails>();
		RechargeDetails Details1 = new RechargeDetails("Airtel","1089343431","Monthly", 210, 4567);
		RechargeDetails Details2 = new RechargeDetails("DishTV","3033221223","Yearly", 1260, 2345);
		RechargeDetails Details3 = new RechargeDetails("Reliance","8923434300","Quaterly", 650, 1234);
		
		list.add(Details1);
		list.add(Details2);
		list.add(Details3);
	}
	
	public RechargeCollectionHelper(){}
	
	//adding RechargeDetails to the array list
	public void addDetails(RechargeDetails details) {
		// TODO Auto-generated method stub
		list.add(details);	
		
	}
	public static ArrayList<RechargeDetails> getlist() {
		return list;
	}
	public static void setlist(ArrayList<RechargeDetails> list) {
		RechargeCollectionHelper.list = list;
	}


	//displaying all RechargeDetails
	public void displayDetails() {
		// TODO Auto-generated method stub
		Iterator<RechargeDetails> itr=list.iterator();
		RechargeDetails temp=null;
		while(itr.hasNext())
		{
			temp=itr.next();
			System.out.println(temp);			
		}
	}

	
}
