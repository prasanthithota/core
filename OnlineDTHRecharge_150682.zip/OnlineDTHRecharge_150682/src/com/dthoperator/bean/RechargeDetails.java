/*******Author Name: sri vani bobbili  Emp Id : 150682 Date: 7/5/2018 ******/
//Purpose: To provide getters and setters for Recharge details
package com.dthoperator.bean;

public class RechargeDetails {

	private String operator;
	private String consumerno;
	private String plan;
	private int amount;
	private long transId;
	
	//default constructor
	public RechargeDetails()
	{
		
	}
	
	//initializing instance variables
	public RechargeDetails(String operator, String consumerno, String plan, int amount, long transId)
	{
		this.operator=operator;
		this.consumerno=consumerno;
		this.plan=plan;
		this.amount=amount;
		this.transId=transId;
	}
	//getter for transaction id
	public long gettransId() 
	{
		return transId;
	}
	//setter for transaction id
	public void settransId(int transId) 
	{
		this.transId = transId;
	}
	//getter for operator
	public String getoperator() 
	{
		return operator;
	}
	//setter for operator
	public void setoperator( String operator) 
    {
		this.operator = operator;
    }
	//getter for consumer no
	public  String getconsumerno() 
	{
		return consumerno;
	}
	//setter for consumer no
	public void setconsumerno( String consumerno) 
	{
		this.consumerno = consumerno;
	}
	//getter for plan
	public  String getplan() 
	{
		return plan;
	}
	//setter for plan
	public void setplan( String plan) 
	{
		this.plan = plan;
	}
    //getter for amount
	public  int getamount() 
	{
		return amount;
	}
	//setter for amount
	public void setamount(int amount) 
	{
		this.amount = amount;
	}
	//displaying operators details 
	@Override
	public String toString() {
		return  "Asset [Transaction Id=" + transId + ", Operator="
							+ operator + ", Consumer No=" + consumerno +", Plan=" + plan
							+ ", Amount=" + amount + "]";
				}

}
